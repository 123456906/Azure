// ================================
// 颜色辅助函数
// ================================

function color(c) {
    return Color.valueOf(c);
}

// ================================
// 创建行星对象
// ================================

const planet = new Planet("tutorial-mod-tutorial-planet", Planets.sun, 1, 3);

// 导入核心
const core = require("Acore");

// ================================
// 设置行星属性
// ================================

planet.localizedName = "⚶";
planet.description = "回响";
planet.details = "这里有人生活过。";

// ================================
// 设置行星外观（网格）
// ================================

planet.meshLoader = prov(() => new HexMesh(planet, 6));

// ================================
// 设置行星云层 - 多彩创意云层
// ================================

planet.cloudMeshLoader = prov(() => new MultiMesh(
    
    new HexSkyMesh(planet, 4, 0.12, 0.18, 5, Color.valueOf("88A4FF80"), 2, 0.42, 1.2, 0.45),
    
    new HexSkyMesh(planet, 6, 0.3, 0.15, 4, Color.valueOf("88A4FF80"), 2, 0.48, 1.3, 0.47),
));

// ================================
// 设置行星生成器（地形生成）- 创意地表颜色
// ================================

planet.generator = extend(SerpuloPlanetGenerator, {

baseSeed: 7,
    
    // 获取默认核心蓝图
    getDefaultLoadout() {
        return Schematics.readBase64("bXNjaAF4nGNgYmBiYWDJS8xNZWB7tmDH0/3NDOzFJamJuZkpDFzFyRmpuYklmcnFDNwpqcXJRZkFJZn5eQwMDGw5iUmpOcUMTNGxjAzyT3fNfzpn/vPlE591Neg+2dHwcsY2oNCzaTOhJjIwMDJAAADBmCrd");
    },
    
    // 是否允许着陆[整颗行星都可以着陆]
    allowLanding(sector) {
        return false;
    }
});

// ================================
// 设置行星大气 - 配合地表的主色调
// ================================

planet.atmosphereColor = Color.valueOf("7B5BFF40");
planet.lightColor = Color.valueOf("9B8BFF60");
planet.atmosphereRadIn = 0;
planet.atmosphereRadOut = 0.3;

// ================================
// 设置行星可见性和可访问性
// ================================

planet.visible = true;
planet.bloom = false;
planet.accessible = true;
planet.alwaysUnlocked = true;

// ================================
// 设置行星环境
// ================================

planet.defaultEnv = Env.terrestrial;

// ================================
// 设置行星轨道参数
// ================================

planet.startSector = 175;
planet.camRadius = 0.5;
planet.orbitRadius = 75;
planet.orbitSpacing = 2;
planet.orbitTime = 240 * 60;
planet.rotateTime = 15 * 60;
planet.iconColor = Color.valueOf("7B5BFFFF");
planet.clearSectorOnLose = true;

// ================================
// 禁用预建基地
// ================================

planet.prebuildBase = false;

// ================================
// 创建星区
// ================================

const testSector = new SectorPreset("testSector", planet, 175);
testSector.captureWave = 20;
testSector.difficulty = 2;
testSector.alwaysUnlocked = true;
testSector.addStartingItems = false;
testSector.localizedName = "testSector";
testSector.description = "测试用区域";

const wreckage = new SectorPreset("wreckage", planet, 15);
wreckage.captureWave = 25;
wreckage.difficulty = 3;
wreckage.alwaysUnlocked = true;
wreckage.addStartingItems = false;
wreckage.localizedName = "wreckage";
wreckage.description = "测试用区域2";

const zero = new SectorPreset("zero", planet, 0);
zero.captureWave = 30;
zero.difficulty = 4;
zero.alwaysUnlocked = true;
zero.addStartingItems = false;
zero.localizedName = "zero";
zero.description = "测试用区域3";

const ott = new SectorPreset("ott", planet, 123);
ott.captureWave = 30;
ott.difficulty = 4;
ott.alwaysUnlocked = true;
ott.addStartingItems = false;
ott.localizedName = "ott";
ott.description = "测试用区域4";

// ================================
// 导出
// ================================

exports.planet = planet;
exports.testSector = testSector;
exports.wreckage = wreckage;
exports.zero = zero;
exports.ott = ott;